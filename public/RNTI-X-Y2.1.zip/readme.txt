Styles RNTI (18 novembre 2005)

Les consignes figurent dans le fichier

 RNTI_consignes_LaTeX.pdf (pour utilisateurs de LaTeX)


RNTI2e_latex.zip   contient 
      rnti.cls, version 2,
      rnti.bst, style bibliographique 
      un guide d'utilisateur
      et des fichiers d'exemples (.tex,.bib, etc.)

      
    
                             